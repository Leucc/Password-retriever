import datetime

today = datetime.datetime.now()
formatted_time = today.strftime("%Y-%m-%d %H:%M:%S")
print(formatted_time)