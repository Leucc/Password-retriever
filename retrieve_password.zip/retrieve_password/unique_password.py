def filter_password(password):
    unique_data = list(set(password))
    return unique_data